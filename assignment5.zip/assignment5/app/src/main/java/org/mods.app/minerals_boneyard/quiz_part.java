package org.mods.app.minerals_boneyard;

/**
 * Created by Lindsey_2 on 7/20/2015.
 */
public class quiz_part {

    int image;
    String question, answer;



}
